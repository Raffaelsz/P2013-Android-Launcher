package com.santos.pes2013launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.DocumentsContract
import android.content.SharedPreferences
import android.content.Context

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private var gameFolderUri: Uri? = null
    private var profile = "Equilibrado"

    private val pickFolder = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pes_launcher", Context.MODE_PRIVATE)
        gameFolderUri = prefs.getString("game_folder", null)?.let { Uri.parse(it) }
        profile = prefs.getString("profile", "Equilibrado") ?: "Equilibrado"
        buildUi()
        updateStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(8, 20, 18), Color.rgb(15, 37, 31), Color.rgb(5, 10, 10))
            )
        }
        scroll.addView(root)
        setContentView(scroll)

        val badge = TextView(this).apply {
            text = "KONAMI-STYLE • FAN PROJECT"
            textSize = 11f
            letterSpacing = 0.14f
            setTextColor(Color.rgb(100, 220, 160))
            gravity = Gravity.CENTER
        }
        root.addView(badge, matchWrap())

        val title = TextView(this).apply {
            text = "PES 2013"
            textSize = 38f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "ANDROID LAUNCHER"
            textSize = 13f
            letterSpacing = 0.22f
            setTextColor(Color.rgb(185, 205, 195))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())

        val hero = TextView(this).apply {
            text = "⚽\n\nPRO EVOLUTION SOCCER\n\nGerencie seus arquivos e prepare sua instalação."
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(30), dp(12), dp(30))
            background = rounded(Color.rgb(22, 54, 43), dp(18), Color.rgb(66, 130, 96))
        }
        val heroParams = matchWrap()
        heroParams.topMargin = dp(22)
        root.addView(hero, heroParams)

        val play = makeButton("JOGAR PES 2013", true) { onPlayPressed() }
        addButton(play, 20)

        addButton(makeButton("SELECIONAR PASTA DO JOGO", false) { chooseGameFolder() }, 10)
        addButton(makeButton("CONFIGURAÇÕES DE DESEMPENHO", false) { showProfiles() }, 10)
        addButton(makeButton("VERIFICAR ARQUIVOS", false) { verifyFiles() }, 10)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(205, 220, 212))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(18), dp(12), dp(8))
        }
        val statusParams = matchWrap()
        statusParams.topMargin = dp(8)
        root.addView(status, statusParams)

        val note = TextView(this).apply {
            text = "Versão inicial 0.1.0 • O runtime de Windows ainda não está integrado."
            textSize = 11f
            setTextColor(Color.rgb(145, 165, 155))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), 0)
        }
        root.addView(note, matchWrap())
    }

    private fun makeButton(label: String, primary: Boolean, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(if (primary) Color.rgb(5, 22, 15) else Color.WHITE)
            background = rounded(
                if (primary) Color.rgb(103, 235, 160) else Color.rgb(27, 49, 41),
                dp(14),
                if (primary) Color.rgb(103, 235, 160) else Color.rgb(65, 100, 82)
            )
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { action() }
        }
    }

    private fun addButton(button: Button, top: Int) {
        val p = matchWrap()
        p.topMargin = dp(top)
        root.addView(button, p)
    }

    private fun chooseGameFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(intent, pickFolder)
    }

    @Deprecated("Legacy callback used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags)
            gameFolderUri = uri
            prefs.edit().putString("game_folder", uri.toString()).apply()
            updateStatus()
            Toast.makeText(this, "Pasta selecionada.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun verifyFiles() {
        val uri = gameFolderUri
        if (uri == null) {
            message("Selecione primeiro a pasta onde está instalado o PES 2013.")
            return
        }
        val foundExe = findChild(uri, "pes2013.exe")
        val foundImg = findChild(uri, "img")
        val result = buildString {
            append("Verificação da pasta selecionada:\n\n")
            append(if (foundExe) "✓ pes2013.exe encontrado\n" else "✗ pes2013.exe não encontrado na raiz\n")
            append(if (foundImg) "✓ pasta img encontrada\n" else "✗ pasta img não encontrada na raiz\n")
            append("\nSe os itens estiverem dentro de uma subpasta, selecione diretamente a pasta principal do jogo.")
        }
        AlertDialog.Builder(this).setTitle("Diagnóstico").setMessage(result)
            .setPositiveButton("OK", null).show()
    }

    private fun findChild(treeUri: Uri, name: String): Boolean {
        return try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            contentResolver.query(
                childrenUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { cursor ->
                val idx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    if (idx >= 0 && cursor.getString(idx).equals(name, ignoreCase = true)) return true
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun showProfiles() {
        val options = arrayOf("Econômico", "Equilibrado", "Desempenho")
        val selected = options.indexOf(profile).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Perfil de desempenho")
            .setSingleChoiceItems(options, selected) { dialog, which ->
                profile = options[which]
                prefs.edit().putString("profile", profile).apply()
                updateStatus()
                dialog.dismiss()
                Toast.makeText(this, "Perfil salvo: $profile", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun onPlayPressed() {
        AlertDialog.Builder(this)
            .setTitle("Runtime ainda necessário")
            .setMessage(
                "A interface do launcher está pronta para evoluir, mas esta versão ainda não executa o PES. " +
                "Precisamos integrar um runtime compatível com jogos Windows de 32 bits e a tradução gráfica. " +
                "O botão Jogar será conectado quando essa etapa estiver implementada."
            )
            .setPositiveButton("Entendi", null)
            .show()
    }

    private fun updateStatus() {
        val folderText = if (gameFolderUri == null) "Pasta do jogo: não selecionada" else "Pasta do jogo: selecionada"
        status.text = "$folderText\nPerfil atual: $profile"
    }

    private fun message(msg: String) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}
